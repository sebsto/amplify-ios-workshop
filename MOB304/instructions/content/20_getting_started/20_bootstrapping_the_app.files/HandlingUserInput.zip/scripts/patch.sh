diff -ruN ./Pods/Amplify ~/Documents/amazon/te/2019/reinvent/mobile\ workshop/workshop/MOB304/code/Complete/Landmarks/Pods/Amplify > patch1.txt 

diff -ruN ./Pods/AWSPluginsCore ~/Documents/amazon/te/2019/reinvent/mobile\ workshop/workshop/MOB304/code/Complete/Landmarks/Pods/AWSPluginsCore > patch2.txt